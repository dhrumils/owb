import os
import glob
import ntpath

from flask import Flask, jsonify, render_template, request, redirect, url_for, Blueprint, send_from_directory
from werkzeug.utils import secure_filename

from gateway import gateway_app

from pdm import pdm_app

app = Flask(__name__)
app.register_blueprint(pdm_app)
app.register_blueprint(gateway_app)

@app.route('/')
def index():
    return redirect('static/webpages/login.html')

if __name__ == '__main__':
    app.run()
