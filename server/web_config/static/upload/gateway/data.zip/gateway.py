import os
import glob
import ntpath
import time
from flask import Flask, jsonify, render_template, request, redirect, url_for, send_from_directory, Blueprint
from werkzeug.utils import secure_filename
from datetime import datetime


gateway_app = Blueprint('gateway_app', __name__)


ALLOWED_EXTENSIONS = set(['css','zip'])

Gateway_Folder = 'static/upload/gateway/'

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@gateway_app.route('/gateway_upload_file', methods=['GET', 'POST'])
def gateway_upload_file():

    result={'result':False}
    print "function called"
    if True:
        if 'gateway_file' not in request.files:
            print 'No file part'
            result['result'] = False
        gateway_file = request.files['gateway_file']
        print "file : " + gateway_file.filename
        if gateway_file.filename == '':
            print 'No selected file'
            result['result'] = False
        elif gateway_file and allowed_file(gateway_file.filename):
            filename = secure_filename(gateway_file.filename)
            print "save gateway_file:" + filename
            timestamp = datetime.now().isoformat()
            print timestamp
            gateway_file.save(os.path.join(Gateway_Folder, filename))
            result['result'] = True
        return jsonify(result)


@gateway_app.route('/fetch_gateway_files', methods=['GET', 'POST'])
def fetch_gateway_files():
        filelist = {'files':[]}

        file_path = glob.glob("static/upload/gateway/*.css")
        print len(file_path)

        for i in range(0,len(file_path)):
            head,tail = os.path.split(file_path[i])
            print tail
            filelist['files'].append(tail)
            print filelist
        return jsonify(filelist)


@gateway_app.route('/delete_gateway_file', methods=['GET', 'POST'])
def delete_gateway_file():
    result={'result':False}
    try:
        filename = request.args.get('filename')
        os.remove(os.path.join(Gateway_Folder, filename))
        result['result'] = True
    except:
        print "Couldn't delete file"
        result['result'] = False
    return jsonify(result)


@gateway_app.route('/rename_gateway_file', methods=['GET', 'POST'])
def rename_gateway_file():
    result={'result':False}
    try:
        oldgatewayFile = request.args.get('oldgatewayFile')
        newgatewayFile = request.args.get('newgatewayFile')
        print oldgatewayFile
        print newgatewayFile
        os.rename(os.path.join(Gateway_Folder,oldgatewayFile), os.path.join(Gateway_Folder,newgatewayFile))
        result['result'] = True
    except:
        print "Couldn't rename file"
        result['result'] = False
    return jsonify(result)
