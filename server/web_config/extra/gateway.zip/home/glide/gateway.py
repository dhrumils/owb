import os
import glob
import ntpath
import time
import json
import zipfile
import MySQLdb
from flask import Flask, jsonify, render_template, request, redirect, url_for, send_from_directory, Blueprint
from werkzeug.utils import secure_filename
from datetime import datetime


gateway_app = Blueprint('gateway_app', __name__)

gateway_table = "gatewaydb"
database_name = "glide$owbserverdb"

ALLOWED_EXTENSIONS = set(['zip','zip'])

Gateway_Folder = 'static/upload/gateway/'

def read_file_info(filename):
    json_decode={}
    zf=zipfile.ZipFile(filename, 'r')
    print zf
    for file in zf.namelist():
    	if file == "file_info.json":
            json_decode=json.loads(zf.read(file))
            print json_decode.get('filename')
            print json_decode.get('major_version')
            print json_decode.get('minor_version')
            print json_decode.get('modified_date')
            print json_decode.get('commit_number')
            print json_decode.get('commit_date')
            print json_decode.get('remarks')
            print json_decode.get('latest')
    return json_decode

def update_database(json_decode):
            db = get_db()
            cursor = db.cursor()
            print "data not inserted"
            sql = 'SELECT * FROM gatewaydb'
            cursor.execute(sql)
            sql = 'INSERT INTO gatewaydb (filename,major_version,minor_version,modified_date,commit_number,commit_date,remarks,latest) VALUES ('+'"'+json_decode.get('filename')+'"'+','+json_decode.get('major_version')+','+json_decode.get('minor_version')+',"2017-06-21",'+json_decode.get('commit_number')+',"'+json_decode.get('commit_date')+'","a",false )'
            #sql1 = 'ON DUPLICATE KEY UPDATE major_version = 'json_decode.get('major_version')',minor_version = 'json_decode.get('minor_version')',modified_date = "2017-06-21", commit_number = 'json_decode.get('commit_number')',commit_date = 'json_decode.get('commit_date')',remarks = "a",latest = false'
            sql1 = 'ON DUPLICATE KEY UPDATE filename = '+'"'+json_decode.get('filename')+'"'+',major_version = '+json_decode.get('major_version')+',minor_version = '+json_decode.get('minor_version')+',modified_date = "2017-08-23",commit_number = '+json_decode.get('commit_number')+',commit_date = "'+json_decode.get('commit_date')+'",remarks = "new remark",latest = true'
            sql=sql+sql1
            cursor.execute(sql)
            data = cursor.fetchall ()
            for row in data:
                print row
            print "data inserted"
            db.commit()
            db.close()


def get_db():
    # Open database connection ( If database is not created don't give dbname)
    db = MySQLdb.connect("glide.mysql.pythonanywhere-services.com","glide","owbserverdb",database_name)
    return(db)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@gateway_app.route('/gateway_upload_file', methods=['GET', 'POST'])
def gateway_upload_file():

    result={'result':False}
    #file_info={}
    print "function called"
    if True:
        if 'gateway_file' not in request.files:
            print 'No file part'
            result['result'] = False
        gateway_file = request.files['gateway_file']
        print "file : " + gateway_file.filename
        if gateway_file.filename == '':
            print 'No selected file'
            result['result'] = False
        elif gateway_file and allowed_file(gateway_file.filename):
            filename = secure_filename(gateway_file.filename)
            print "save gateway_file:" + filename
            #timestamp = datetime.now().isoformat()
            #print timestamp
            gateway_file.save(os.path.join(Gateway_Folder, filename))
            file_info=read_file_info(os.path.join(Gateway_Folder, filename))
            update_database(file_info)
            result['result'] = True
        return jsonify(result)


@gateway_app.route('/fetch_gateway_files', methods=['GET', 'POST'])
def fetch_gateway_files():
        file_info={}
        filelist = {'files':[]}

        file_path = glob.glob("static/upload/gateway/*.zip")
        print len(file_path)
        db = get_db()
        cursor = db.cursor()
        for i in range(0,len(file_path)):
            head,tail = os.path.split(file_path[i])
            print "Tail:" + tail
            sql='select * from '+gateway_table+' where filename="'+tail+'"'
            cursor.execute(sql)
            data = cursor.fetchall ()
            for row in data:
                print row[0]
                file_info = file_info.copy()
                file_info['filename'] = row[0]
                file_info['major_version'] = row[1]
                file_info['minor_version'] = row[2]
                file_info['modified_date'] = row[3]
                file_info['commit_number'] = row[4]
                file_info['commit_date'] = row[5]
                file_info['remarks'] = row[6]
                file_info['latest'] = row[7]
                filelist['files'].append(file_info)
            print filelist
        return jsonify(filelist)


@gateway_app.route('/delete_gateway_file', methods=['GET', 'POST'])
def delete_gateway_file():
    result={'result':False}
    try:
        db=get_db()
        cursor = db.cursor()
        filename = request.args.get('filename')
        os.remove(os.path.join(Gateway_Folder, filename))
        sql = 'DELETE from '+gateway_table+' where filename="'+filename+'"'
        cursor.execute(sql)
        db.commit()
        db.close
        result['result'] = True
    except:
        print "Couldn't delete file"
        result['result'] = False
    return jsonify(result)


@gateway_app.route('/rename_gateway_file', methods=['GET', 'POST'])
def rename_gateway_file():
    result={'result':False}
    try:
        db=get_db()
        cursor = db.cursor()
        old_remarks = request.args.get('old_remarks')
        filename = request.args.get('filename')
        remarks = request.args.get('remarks')
        print "Old remarks: " + old_remarks
        print "EDIT: " + remarks
        sql = 'UPDATE '+gateway_table+' SET remarks="'+remarks+'" where filename="'+filename+'"'
        cursor.execute(sql)
        db.commit()
        db.close
        result['result'] = True
    except:
        print "Couldn't rename file"
        result['result'] = False
    return jsonify(result)


@gateway_app.route('/gateway_save_btn_click', methods=['GET','POST'])
def gateway_save_btn_click():
    result={'result':False}
    try:
        filename = request.args.get('filename')
        print "filename1: " + filename
        db = get_db()
        cursor = db.cursor()
        sql = 'SELECT * FROM '+gateway_table
        #db_file = 'SELECT '+COLUMN_NAME+' FROM '+gateway_table.COLUMNS+' WHERE TABLE_SCHEMA="'+yourdatabasename+'" AND TABLE_NAME="'+gatewaydb+'"'
        cursor.execute(sql)

        data = cursor.fetchall ()
        for row in data:
            print filename + " " + row[0]
            if (filename == row[0]):
                sql = 'UPDATE '+gateway_table+' SET latest = "true" where filename="'+row[0]+'"'
            else:
                sql = 'UPDATE '+gateway_table+' SET latest = "false" where filename="'+row[0]+'"'
            cursor.execute(sql)
        db.commit()
        db.close()
        result['result'] = True
    except:
        print "Couldn't save file"
        result['result'] = False
    return jsonify(result)

@gateway_app.route('/gateway_delete_btn_click', methods=['GET','POST'])
def gateway_delete_btn_click():
    result={'result':False}
    try:
        filename = request.args.get('filename')
        db=get_db()
        cursor = db.cursor()
        sql = 'UPDATE '+gateway_table+' SET latest="false" where filename="'+filename+'"'
        cursor.execute(sql)
        db.commit()
        db.close
        result['result'] = True
    except:
        print "Couldn't reset files"
        result['result'] = False
    return jsonify(result)
