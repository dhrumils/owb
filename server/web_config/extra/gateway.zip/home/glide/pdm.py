import os
import glob
import ntpath
from flask import Flask, jsonify, render_template, request, redirect, url_for, send_from_directory, Blueprint
from werkzeug.utils import secure_filename
from datetime import datetime


pdm_app = Blueprint('pdm_app', __name__)


ALLOWED_EXTENSIONS = set(['css','zip'])

Pdm_Folder = 'static/upload/pdm/'


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@pdm_app.route('/pdm_upload_file', methods=['GET', 'POST'])
def pdm_upload_file():

    result={'result':False}
    print "function called"
    if True:
        if 'pdm_file' not in request.files:
            print 'No file part'
            result['result'] = False
        pdm_file = request.files['pdm_file']
        print "file : " + pdm_file.filename
        if pdm_file.filename == '':
            print 'No selected file'
            result['result'] = False
        elif pdm_file and allowed_file(pdm_file.filename):
            filename = secure_filename(pdm_file.filename)
            print "save pdm_file:" + filename
            timestamp = datetime.now().isoformat()
            print timestamp
            pdm_file.save(os.path.join(Pdm_Folder, filename))
            result['result'] = True
    return jsonify(result)

@pdm_app.route('/pdm_fetch_files', methods=['GET', 'POST'])
def pdm_fetch_files():
        filelist = {'files':[]}

        file_path = glob.glob("static/upload/pdm/*.css")
        print len(file_path)

        for i in range(0,len(file_path)):
            head,tail = os.path.split(file_path[i])
            print tail
            filelist['files'].append(tail)
            print filelist
        return jsonify(filelist)


@pdm_app.route('/delete_file', methods=['GET', 'POST'])
def delete_file():
    result={'result':False}
    try:
        filename = request.args.get('filename')
        os.remove(os.path.join(Pdm_Folder, filename))
        result['result'] = True
    except:
        print "Couldn't delete file"
        result['result'] = False
    return jsonify(result)


@pdm_app.route('/rename_file', methods=['GET', 'POST'])
def rename_file():
    result={'result':False}
    try:
        oldPdmFile = request.args.get('oldPdmFile')
        newPdmFile = request.args.get('newPdmFile')
        print oldPdmFile
        print newPdmFile
        os.rename(os.path.join(Pdm_Folder,oldPdmFile), os.path.join(Pdm_Folder,newPdmFile))
        result['result'] = True
    except:
        print "Couldn't rename file"
        result['result'] = False
    return jsonify(result)
