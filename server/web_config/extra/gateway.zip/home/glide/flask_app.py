import os
import glob
import ntpath
import MySQLdb
from flask import Flask, jsonify, render_template, request, redirect, url_for, Blueprint, send_from_directory
from werkzeug.utils import secure_filename

from gateway import gateway_app

from pdm import pdm_app

app = Flask(__name__)
app.register_blueprint(pdm_app)
app.register_blueprint(gateway_app)

gateway_table = "gatewaydb"
database_name = "glide$owbserverdb"

@app.route('/')
def index():
    return redirect('static/webpages/login.html')

if __name__ == '__main__':
# database creation
    db1 = MySQLdb.connect(host="glide.mysql.pythonanywhere-services.com",user="glide",passwd="owbserverdb")
    cursor = db1.cursor()

    sql = 'CREATE DATABASE IF NOT EXISTS ' + database_name
    cursor.execute(sql)
    sql = 'USE ' + database_name
    cursor.execute(sql)
#database table creation
    sql = '''CREATE TABLE  IF NOT EXISTS '''+  gateway_table+'''(
    filename varchar(25),
    major_version varchar(5),
    minor_version varchar(5),
    modified_date Date,
    commit_number varchar(12),
    commit_date Date,
    remarks varchar(50),
    latest varchar(20),
    UNIQUE (filename)
    )
    '''
    cursor.execute(sql)
    db1.close()
    app.run()
