function onPdmUploadBtnClick() {
    var text= $("#PdmFileTextBox").val();
    var formData = new FormData();
    formData.append('pdm_file', $('#pdm_file')[0].files[0]);

    $.ajax({
       url : '/pdm_upload_file',
       type : 'POST',
       data : formData,
       processData: false,  // tell jQuery not to process the data
       contentType: false,  // tell jQuery not to set contentType
       success : function(data) {
           console.log(data);
           if(data['result'] == true) {
             alert("File uploaded successfully");
             pdm_fetch_files();
           } else {
             alert("Could not upload the file!");
           }
       }
    });
}

function pdm_fetch_files(){
   $.getJSON("/pdm_fetch_files" , onGetPdmFilesSuccess , onGetPdmFilesFailed);
   document.getElementById("PdmFileTextBox").value = " ";
}

function onGetPdmFilesSuccess(filelist){
    addPdmRow(filelist);
}

function onGetPdmFilesFailed(data){
    alert("Couldn't get Files");
}

function addPdmRow(filelist) {
    var table = document.getElementById("table_pdm_id");
    var rowCount = table.rows.length;

    //loop for table refresh
    for(var i = rowCount - 1 ; i >= 1 ; i--) {
        table.deleteRow(i);
    }

    rowCount = table.rows.length;

    var element;

    for (i=0; i<filelist['files'].length; i++){
      var row = table.insertRow(rowCount+i);
      row.id =  rowCount + i;
    //  alert("row" + row.id);
      var cellNum=0
      var cell = row.insertCell(cellNum);

      element = document.createElement('input');
      element.setAttribute('type','radio');
      element.id="Radio_Btn"+(rowCount + i);
      element.name = "Radio"
      element.innerHTML = "";
      element.setAttribute('onclick','onPdmRadioClicked()');
      cell.appendChild(element);
      cell.align = "center";
      var radio = "<input id='"+(i)+"'"+" onclick='onPdmRadioClicked()'>";
      cellNum++;

      cell = row.insertCell(cellNum);
      element = document.createElement("span");
      //element.contentEditable= true;
      element.id="File_Name"+(rowCount + i);
      element.innerHTML = filelist['files'][i];
      cell.appendChild(element);
      cell.align = "left";
      cellNum++;

      cell = row.insertCell(cellNum);
      element = document.createElement("span");
      element.id="Date"+(rowCount + i);
      element.innerHTML = row.id;
      cell.appendChild(element);
      cell.align = "left";
      cellNum++;

      cell = row.insertCell(cellNum);
      element = document.createElement("span");
      element.id="Remarks"+(rowCount + i);
      element.innerHTML = "Remarks";
      cell.appendChild(element);
      cell.align = "left";
      cellNum++;

      cell = row.insertCell(cellNum);
      element = document.createElement("span");
      element.id="Version"+(rowCount + i);
      element.innerHTML = "Version";
      cell.appendChild(element);
      cell.align = "left";
      cellNum++;

      cell = row.insertCell(cellNum);
      element = document.createElement("span");
      element.id= "Radio_btn"+i;
      var pencilIcon ="<button id='"+(i)+"'"+"onclick='onPdmPencilClicked(this.id)'class='glyphicon glyphicon-pencil' style='padding-right:10px;background:transparent;border:none;'()></button>";
      var trashIcon = "<button id='"+(i)+"'"+" onclick='onPdmTrashClicked(this.id)' class='glyphicon glyphicon-trash' style='padding-right:10px;background:transparent;border:none;'></button>";
      var downloadIcon = "<button id='"+(i)+"'"+" onclick='onPdmDownloadClicked(this.id)' class='glyphicon glyphicon-download-alt' style='padding-right:10px;background:transparent;border:none;'></button>"
      element.innerHTML = "";
      cell.appendChild(element);
      $("#Radio_btn"+i).append(pencilIcon + trashIcon + downloadIcon);
      cell.align = "left";
      cellNum++;
    }
}

var oldPdmFile, newPdmFile;
function onPdmPencilClicked(e){
  row = parseInt(e)+1;
  oldPdmFile=document.getElementById("File_Name"+row).innerHTML;
  document.getElementById("File_Name"+row).focus();
  document.getElementById("File_Name"+row).contentEditable = true;
  document.getElementById("File_Name"+row).focus();
  placeCaretAtEnd( document.getElementById("File_Name"+row) );
  $("#File_Name"+row).on('keypress', function(event) {
        if (event.keyCode == 13) {
            newPdmFile=document.getElementById("File_Name"+row).innerHTML;
            document.getElementById("File_Name"+row).contentEditable = false;
            renamePdmFile();
        }
    });
}



function renamePdmFile() {
   //alert (oldPdmFile+"-"+newPdmFile);
   $.getJSON("/rename_file" ,{'oldPdmFile':oldPdmFile,'newPdmFile':newPdmFile}, onPdmRenameSuccess, onPdmRenameFailed);
}

function onPdmRenameSuccess(data) {
  if (data['result'] == true) {
    pdm_fetch_files();
  } else {
    alert("Couldn't rename file");
  }
}

function onPdmRenameFailed(){
  alert("Couldn't rename file");
}



function onPdmTrashClicked(e){
  row = parseInt(e)+1;              // a=row id, e=rowid -1//// e= button id
  var fileName=document.getElementById("File_Name"+row).innerHTML;
  alert(fileName);
  delete_Pdm_File(fileName);
}

function delete_Pdm_File(fileName) {
   $.getJSON("/delete_file" ,{'filename':fileName.toString()}, onPdmDeleteSuccess , onPdmDeleteFailed);
}

function onPdmDeleteSuccess(data) {
  if (data['result'] == true) {
    pdm_fetch_files();
  } else {
    alert("Couldn't delete file");
  }
}

function onPdmDeleteFailed(){
  alert("Couldn't delete file");
}


function onPdmRadioClicked(){
    document.getElementById("btn_save").disabled = false;
    document.getElementById("btn_cancel").disabled = false;
}

function placeCaretAtEnd(el) {
    el.focus();
    if (typeof window.getSelection != "undefined"
            && typeof document.createRange != "undefined") {
        var range = document.createRange();
        range.selectNodeContents(el);
        range.collapse(false);
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
    } else if (typeof document.body.createTextRange != "undefined") {
        var textRange = document.body.createTextRange();
        textRange.moveToElementText(el);
        textRange.collapse(false);
        textRange.select();
    }
}
