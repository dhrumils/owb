function onGatewayUploadBtnClick() {
    var text= $("#GatewayFileTextBox").val();
    var formData = new FormData();
    formData.append('gateway_file', $('#gateway_file')[0].files[0]);

    $.ajax({
       url : '/gateway_upload_file',
       type : 'POST',
       data : formData,
       processData: false,  // tell jQuery not to process the data
       contentType: false,  // tell jQuery not to set contentType
       success : function(data) {
           console.log(data);
           if(data['result'] == true) {
             alert("File uploaded successfully");
             get_gateway_files();
           } else {
             alert("Could not upload the file!");
           }
       }
    });
}

function get_gateway_files(){
   $.getJSON("/fetch_gateway_files" , onGetFilesSuccess , onGetFilesFailed);
   document.getElementById("GatewayFileTextBox").value = " ";
}

function onGetFilesSuccess(filelist){
    addGatewayRow(filelist);
}

function onGetFilesFailed(data){
    alert("Couldn't get Files");
}

function addGatewayRow(filelist) {
    var table = document.getElementById("gateway_table_id");
    var rowCount = table.rows.length;

    //loop for table refresh
    for(var i = rowCount - 1 ; i >= 1 ; i--) {
        table.deleteRow(i);
    }

    rowCount = table.rows.length;

    var element;

    for (i=0; i<filelist['files'].length; i++){
      var row = table.insertRow(rowCount+i);
      row.id =  rowCount + i;
    //  alert("row" + row.id);
      var cellNum=0
      var cell = row.insertCell(cellNum);

      element = document.createElement('input');
      element.setAttribute('type','radio');
      element.id="Radio_Btn"+(rowCount + i);
      element.name = "Radio"
      element.innerHTML = "";
      if (filelist['files'][i]['latest'] == 'true') {
        element.checked= true;
      }
      //alert(element.id);
      element.setAttribute('onclick','onGatewayRadioClicked()');
      cell.appendChild(element);
      cell.align = "center";
      var radio = "<input id='"+(i)+"'"+" onclick='onGatewayRadioClicked()'>";
      cellNum++;

      cell = row.insertCell(cellNum);
      element = document.createElement("span");
      //element.contentEditable= true;
      element.id="File_Name"+(rowCount + i);
      element.innerHTML = filelist['files'][i]['filename'];
      cell.appendChild(element);
      cell.align = "left";
      cellNum++;

      cell = row.insertCell(cellNum);
      element = document.createElement("span");
      element.id="Date"+(rowCount + i);
      element.innerHTML = filelist['files'][i]['modified_date'];
      cell.appendChild(element);
      cell.align = "left";
      cellNum++;

      cell = row.insertCell(cellNum);
      element = document.createElement("span");
      element.id="Remarks"+(rowCount + i);
      element.innerHTML = filelist['files'][i]['remarks'];
      cell.appendChild(element);
      cell.align = "center";
      cellNum++;

      cell = row.insertCell(cellNum);
      element = document.createElement("span");
      element.id="Version"+(rowCount + i);
      element.innerHTML = filelist['files'][i]['major_version']+'.'+filelist['files'][i]['minor_version'];
      cell.appendChild(element);
      cell.align = "left";
      cellNum++;

      cell = row.insertCell(cellNum);
      element = document.createElement("span");
      element.id= "Gateway_Radio_btn"+i;
      var pencilIcon ="<button id='"+(i)+"'"+"onclick='onGatewayPencilClicked(this.id)'class='glyphicon glyphicon-pencil' style='padding-right:10px;background:transparent;border:none;'()></button>";
      var trashIcon = "<button id='"+(i)+"'"+" onclick='onGatewayTrashClicked(this.id)' class='glyphicon glyphicon-trash' style='padding-right:10px;background:transparent;border:none;'></button>";
      var downloadIcon = "<button id='"+(i)+"'"+" onclick='onGatewayDownloadClicked(this.id)' class='glyphicon glyphicon-download-alt' style='padding-right:10px;background:transparent;border:none;'></button>"
      element.innerHTML = "";
      cell.appendChild(element);
      $("#Gateway_Radio_btn"+i).append(pencilIcon + trashIcon + downloadIcon);
      cell.align = "left";
      cellNum++;
    }
}

var old_remarks, filename, remarks;
function onGatewayPencilClicked(e){
  row = parseInt(e)+1;
  filename = document.getElementById("File_Name"+row).innerHTML;
  old_remarks=document.getElementById("Remarks"+row).innerHTML;
  document.getElementById("Remarks"+row).focus();
  document.getElementById("Remarks"+row).contentEditable = true;
  document.getElementById("Remarks"+row).focus();
  placeCaretAtEnd( document.getElementById("Remarks"+row) );
  $("#Remarks"+row).on('keypress', function(event) {
        if (event.keyCode == 13) {
            remarks=document.getElementById("Remarks"+row).innerHTML;
            document.getElementById("Remarks"+row).contentEditable = false;
            rename_gateway_file();
        }
    });
}

function rename_gateway_file() {
   $.getJSON("/rename_gateway_file" ,{'old_remarks':old_remarks, 'filename':filename, 'remarks':remarks}, onGatewayRenameSuccess, onGatewayRenameFailed);
}

function onGatewayRenameSuccess(data) {
  if (data['result'] == true) {
    get_gateway_files();
  } else {
    alert("Couldn't rename file");
  }
}

function onGatewayRenameFailed(){
  alert("Couldn't rename file");
}



function onGatewayTrashClicked(e){
  row = parseInt(e)+1;              // a=row id, e=rowid -1//// e= button id
  var fileName=document.getElementById("File_Name"+row).innerHTML;
  //alert(fileName);
  delete_gateway_file(fileName);
}

function delete_gateway_file(fileName) {
   $.getJSON("/delete_gateway_file" ,{'filename':fileName.toString()}, onGatewayDeleteSuccess , onGatewayDeleteFailed);
}

function onGatewayDeleteSuccess(data) {
  if (data['result'] == true) {
    get_gateway_files();
  } else {
    alert("Couldn't delete file");
  }
}

function onGatewayDeleteFailed(){
  alert("Couldn't delete file");
}

function onGatewayDownloadClicked(e){
  row = parseInt(e) + 1;
  alert(row);
  alert(document.getElementById("File_Name"+row).innerHTML);
   window.open("../upload/gateway/*.zip");//+document.getElementById("File_Name"+row).innerHTML);
}

function onGatewayRadioClicked(){
    document.getElementById("gateway_save_btn").disabled = false;
    document.getElementById("gateway_cancel_btn").disabled = false;

}
function onGatewayCancelBtnClicked(){
    $.getJSON("/gateway_delete_btn_click" ,{'filename':filename});
    document.getElementById("gateway_save_btn").disabled = true;
}
function onGatewaySaveBtnClicked(){
    var table = document.getElementById("gateway_table_id");
    var rowCount = table.rows.length;
    var filename;
    for(i=1;i<=rowCount;i++) {
      if (document.getElementById("Radio_Btn"+i).checked == true) {
        filename=document.getElementById("File_Name"+i).innerHTML;
        break;
      }
    }
    if (filename){
      $.getJSON("/gateway_save_btn_click" ,{'filename':filename}, onGatewaySaveBtnClickSuccess, onGatewaySaveBtnFailed);
      document.getElementById("gateway_save_btn").disabled = true;
    }
}
function onGatewaySaveBtnClickSuccess(){
    //document.getElementById("Radio_Btn").checked = false;
}
function onGatewaySaveBtnFailed(){
    alert ("failed to save");
}
function placeCaretAtEnd(el) {
    el.focus();
    if (typeof window.getSelection != "undefined"
            && typeof document.createRange != "undefined") {
        var range = document.createRange();
        range.selectNodeContents(el);
        range.collapse(false);
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
    } else if (typeof document.body.createTextRange != "undefined") {
        var textRange = document.body.createTextRange();
        textRange.moveToElementText(el);
        textRange.collapse(false);
        textRange.select();
    }
}
